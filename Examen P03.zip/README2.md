# Prova Practica 03 (B) - Reserves de Materials amb Retrofit

**Modul:** M07 - Desenvolupament d'interficies
**Cicle:** DAM
**Durada:** 2 hores

---

## Context

Una escola necessita una aplicacio Android per gestionar les reserves de material tecnologic (portatils, projectors, tablets, etc.). Ja existeix una API REST desplegada que gestiona els usuaris, materials i reserves.

**URL base de la API:** `https://oracleitic.mooo.com`
**Documentacio de la API:** `https://oracleitic.mooo.com/docs`

Cadascú de vosaltres teniu un usuari que és el vostre email del centre, i el password: 1357924680

---

## Objectiu

Desenvolupar el codi Kotlin d'una aplicacio Android que consumeixi l'API REST utilitzant **Retrofit**. L'aplicacio ha de permetre:

1. Fer login amb un nom d'usuari
2. Veure la llista de reserves de l'usuari

Les pantalles (layouts XML i drawables) ja estan proporcionades a la carpeta `layouts/`. Nomes cal programar el codi Kotlin.

---

## Pantalles

### Pantalla 1: Login

![Login](layouts/pantalla_login.png)

**Fitxer:** `activity_login.xml`

### Pantalla 2: Llista de Reserves

![Reserves](layouts/pantalla_reserves.png)

**Fitxers:** `activity_reserves.xml` + `item_reserva.xml`

---

## Que cal implementar

### 1. Data Classes

Crear les **data classes** necessaries a partir de la documentacio de la API (`/docs`). Consulteu els esquemes (schemas) per determinar els camps i tipus de cada model.

### 2. Retrofit

- Crear una interface i una classe   `Service` i `Api` amb les funcions necessaries
- Configurar el `Retrofit.Builder` amb la URL base
- Utilitzar `GsonConverterFactory` per a la serialitzacio/deserialitzacio
    
### 3. Login amb LoginViewModel (Clean Code)

Utilitzar el patro **MVVM** amb un ViewModel per a la pantalla de Login:

- **`LoginViewModel`**: gestionar la logica de login (crida a la API, control d'errors)
- L'Activity observa les dades del ViewModel (amb `LiveData`)

**Separacio de responsabilitats (important):**

- L'**Activity** nomes s'encarrega de la UI: observar el ViewModel, actualitzar les vistes i gestionar la navegacio.
- El **ViewModel** conte tota la logica de negoci: crides a la API, transformacio de dades i control d'errors.
- L'Activity **mai** ha de cridar Retrofit directament. Totes les crides a la API es fan des del ViewModel.

### 4. Pantalla de Reserves

Despres d'un login correcte, navegar a la pantalla de reserves.

A la pantalla de reserves:

- Obtenir l'id de l'usuari logejat (podeu utilitzar el metode que considereu mes adient: Intent, variable global, classe Application, etc.)
- Cridar l'endpoint de reserves per obtenir la llista de reserves d'aquest usuari
- Mostrar les reserves en un **RecyclerView** (Adapter + ViewHolder)
- Per cada reserva, mostrar: descripcio del material, data de reserva i data final
- Les dates de la API venen en format ISO (`2026-03-16T00:00:00`). Per mostrar nomes la data (`2026-03-16`), podeu utilitzar `.substring(0, 10)`

---

## Endpoints a utilitzar

| Metode   | Endpoint                                          | Descripcio                             |
|----------|---------------------------------------------------|----------------------------------------|
| `POST`   | `/login/`                                         | Login (body JSON: `{"nom": "...", "password": "..."}`) |
| `GET`    | `/reserves/usuari/{idusuari}`                     | Obtenir totes les reserves d'un usuari (inclou descripcio i imatge del material) |

---

## Dependencies

```kotlin
    // Corrutines amb viewmodel
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.4.0")
    // Retrofit Core
    implementation("com.squareup.retrofit2:retrofit:2.9.0")
    // Converter per gestionar JSON (Generalment es fa servir GSON)
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")
    // (Opcional) Interceptor per poder veure els logs de les peticions (molt útil per a debug)
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // Glide (per carregar imatges)
    implementation("com.github.bumptech.glide:glide:4.16.0")
```
## Permisos aplicació

Recordeu que cal afegir el permís per connectar-se a internet:

```xml
<uses-permission android:name="android.permission.INTERNET" />

```

---

## Criteris d'avaluacio

| Criteri                                                | Puntuacio |
|--------------------------------------------------------|-----------|
| Data classes correctes                                 | 1 punt    |
| Configuracio de Retrofit (ApiService + Builder)        | 2 punts   |
| Login funcional amb LoginViewModel (MVVM)              | 3 punts   |
| RecyclerView amb reserves de l'usuari (Adapter + ViewHolder) | 3 punts   |
| Clean Code MVVM (separacio Activity/ViewModel)          | 1 punt    |
| **Total**                                              | **10 punts** |
| Extra: Glide per carregar imatges                      | +1 punt   |
| Extra: Format de dates amb extension functions         | +1 punt   |

---

## Extras

### Extra 1: Glide (+1 punt)

Utilitzar la llibreria **Glide** per carregar les imatges dels materials a cada element del RecyclerView.

Les imatges es troben a la URL: `https://oracleitic.mooo.com/imatges/{nom_imatge}`

Afegiu la seguent dependencia al `build.gradle` del modul (app):

```kotlin
// Glide (per carregar imatges)
implementation("com.github.bumptech.glide:glide:4.16.0")
```

### Extra 2: Format de dates amb extension functions (+1 punt)

En lloc de mostrar la data com `2026-03-16`, crear una **extension function** que la converteixi a format `dd/MM/yyyy`:

```kotlin
import java.text.SimpleDateFormat
import java.util.Locale

// Extension function per convertir "2026-03-16" a "16/03/2026"
fun String.toDisplayDate(): String {
    val inputFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val outputFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    return try {
        val date = inputFormat.parse(this)
        outputFormat.format(date!!)
    } catch (e: Exception) {
        this
    }
}
```

Aplicar-la a les dates de reserva i data final en comptes de fer el `.substring(0, 10)`.

---

## Notes importants

- La API utilitza un certificat autosignat. Cal afegir la configuracio necessaria per acceptar-lo al client HTTP d'OkHttp, tal com tenim fet en les activitats de classe.
